package exemples;
import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;


public class BordLayout {
	
	JFrame frame = new JFrame("Border Layout D�mo");
	JButton b1 = new JButton ("Nord");
	JButton b2 = new JButton ("Sud");
	JButton b3 = new JButton ("Est");
	JButton b4 = new JButton ("West");
	JButton b5 = new JButton ("Centre");
	

	public BordLayout() {
		frame.setLayout(new BorderLayout());
		frame.setBounds(200, 200, 450, 300);
		frame.setLocationRelativeTo(null);
		frame.add(b1, BorderLayout.NORTH);
		frame.add(b2, BorderLayout.SOUTH);
		frame.add(b3, BorderLayout.EAST);
		frame.add(b4, BorderLayout.WEST);
		frame.add(b5, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				new BordLayout();
			}
			
			
		} );
	}

}
