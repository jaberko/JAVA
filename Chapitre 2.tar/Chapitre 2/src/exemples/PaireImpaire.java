package exemples;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PaireImpaire extends JFrame {

	private JPanel contentPane;
	private JTextField T1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PaireImpaire frame = new PaireImpaire();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PaireImpaire() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 200);
		setLocationRelativeTo(null);
		setTitle("Calcul de parit�");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Paire / Impaire");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int A=0;
		        A = Integer.parseInt(T1.getText());
		       
		       try {
		       
		       if ((A % 2) == 0) {
		            JOptionPane.showMessageDialog(null,"Vous Venez de taper un entier PAIRE ","Parit� (arithm�tique)", 				JOptionPane.INFORMATION_MESSAGE);
		       		T1.setText("");
		       }else {
		            JOptionPane.showMessageDialog(null,"Vous Venez de taper un entier IMPAIRE", "Parit� (arithm�tique)", 				JOptionPane.INFORMATION_MESSAGE);
		       		T1.setText("");}
		       }catch(Exception ex) {
		    	   ex.getMessage();
		       }
		        
		        
			}
		});
		btnNewButton.setBounds(291, 75, 118, 23);
		contentPane.add(btnNewButton);
		
		T1 = new JTextField("");
		T1.setBounds(168, 76, 86, 20);
		contentPane.add(T1);
		T1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Saisir nombre");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(26, 79, 118, 14);
		contentPane.add(lblNewLabel);
	}
}
