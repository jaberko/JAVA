package exemples;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JList;
import javax.swing.JComboBox;
import java.awt.event.ItemEvent;

public class Composants extends JFrame {

	private JPanel contentPane;

		public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Composants frame = new Composants();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Composants() {
		setTitle("Les �v�nements des composants graphiques");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn1 = new JButton("Bouton 2");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Le boutton 2 est cliqu�");
			}
		});
		btn1.setBounds(223, 25, 89, 23);
		contentPane.add(btn1);
		
		JButton btn2 = new JButton("Bouton 1");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Le bouton 1 est cliqu�");
			}
		});
		btn2.setBounds(97, 25, 89, 23);
		contentPane.add(btn2);
		
		JCheckBox coche1 = new JCheckBox("case 1");
		coche1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (coche1.isSelected()) {System.out.println("La case 1 ");}
			}
		});
		coche1.setBounds(97, 67, 97, 23);
		contentPane.add(coche1);
		coche1.setSelected(true);
		
		JCheckBox coche2 = new JCheckBox("case 2");
		coche2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(coche2.isSelected()){	System.out.println("La case 2 ");}
			}
		});
		coche2.setBounds(223, 67, 97, 23);
		contentPane.add(coche2);
		
		JRadioButton br2 = new JRadioButton("radio2");
		br2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(br2.isSelected()){	System.out.println("Radio 2 is selected");}
			}
		});
		br2.setBounds(223, 108, 109, 23);
		contentPane.add(br2);
		
		JRadioButton br1 = new JRadioButton("radio 1");
		br1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(br1.isSelected()){	System.out.println("Radio 1 is selected");}
			}
		});
		br1.setBounds(97, 108, 109, 23);
		contentPane.add(br1);
		ButtonGroup groupe = new ButtonGroup();
		groupe.add(br1);
		groupe.add(br2);
		
		// Combobox
		String[] couleurs={"rouge", "bleu", "gris", "vert","jaune", "noir"};

		JComboBox listeCombo = new JComboBox(couleurs);
		listeCombo.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String val=(String) listeCombo.getSelectedItem();
				System.out.println(val);
			}
		});
		listeCombo.setBounds(97, 143, 89, 22);	
		
		contentPane.add(listeCombo);

		
	}
}
