package exemples;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.GridLayout;
import java.awt.Container;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;


public class MyFrame extends JFrame{
	
	
	public MyFrame() {
		setTitle("BoxLayout"); setSize(100, 550);

		Box bHor= Box.createVerticalBox();
        getContentPane().add(bHor);
        JLabel etiq = new JLabel("Bonjour");   bHor.add(etiq);
        JButton b1 = new JButton("Button 1");  bHor.add(b1);
        JTextField txt = new JTextField(20);   bHor.add(txt);
        JCheckBox coche = new JCheckBox("case � cocher");           
        bHor.add(coche);


	}
	
}
